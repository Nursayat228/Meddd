# UML-диаграмма «Медицинский портал»

```mermaid
classDiagram
    direction TB
    class Person {
        <<abstract>>
        +int Id
        +string FullName
        +DateTime BirthDate
        +GetAge() int
        +DisplayInfo()* void
    }
    class IPayable {
        <<interface>>
        +CalculatePayment() decimal
    }
    class Patient {
        +int PatientId
        +string PhoneNumber
        +string Email
        +string Address
        +UpdateProfile() void
        +DisplayInfo() void
    }
    class Doctor {
        +int DoctorId
        +string Specialization
        +int Experience
        +int CabinetNumber
        +decimal Salary
        +UpdateSpecialization() void
        +CalculateSalary() decimal
        +CalculatePayment() decimal
        +IsDoctorAvailable(DateTime) bool
        +DisplayInfo() void
    }
    class Department {
        +int DepartmentId
        +string DepartmentName
        +int Floor
        +string PhoneNumber
        +Doctor HeadDoctor
        +AddDoctor() bool
        +RemoveDoctor() bool
        +DisplayDoctors() void
    }
    class Appointment {
        +int AppointmentId
        +DateTime AppointmentDate
        +TimeSpan AppointmentTime
        +AppointmentStatus Status
        +CreateAppointment()$ Appointment
        +ConfirmAppointment() string
        +CancelAppointment() string
        +DisplayAppointment() void
    }
    class AppointmentStatus {
        <<enumeration>>
        Scheduled
        Confirmed
        Completed
        Cancelled
    }
    class MedicalRecord {
        +int RecordId
        +string Diagnosis
        +string MedicalHistory
        +DateTime CreationDate
        +AddDiagnosis() void
        +UpdateHistory() void
        +DisplayRecord() void
    }
    class MedicalTest {
        +int TestId
        +string TestName
        +DateTime TestDate
        +string Result
        +AddResult() void
        +UpdateResult() void
        +DisplayResult() void
    }
    class Prescription {
        +int PrescriptionId
        +string MedicationName
        +string Dosage
        +int Duration
        +CreatePrescription()$ Prescription
        +UpdatePrescription() void
        +DisplayPrescription() void
    }
    class MedicalService {
        +int ServiceId
        +string ServiceName
        +decimal Price
        +int Duration
        +CalculatePrice() decimal
        +UpdatePrice() void
        +DisplayService() void
    }
    class Payment {
        +int PaymentId
        +decimal Amount
        +DateTime PaymentDate
        +PaymentStatus PaymentStatus
        +MakePayment() bool
        +RefundPayment() bool
        +DisplayPayment() void
    }

    Person <|-- Patient
    Person <|-- Doctor
    IPayable <|.. Doctor
    IPayable <|.. Payment
    Patient "1" --> "0..*" Appointment : имеет записи
    Doctor "1" --> "0..*" Appointment : принимает
    Appointment ..> AppointmentStatus
    Department "0..*" o-- "1..*" Doctor : агрегация
    Patient "1" *-- "1" MedicalRecord : композиция
    Patient "1" --> "0..*" MedicalTest
    Patient "1" --> "0..*" Prescription
    Doctor "1" --> "0..*" Prescription : выписывает
    Patient "1" --> "0..*" Payment
    Payment "0..*" --> "0..1" MedicalService
```
