using System.ComponentModel.DataAnnotations;

namespace MedicalPortal.Models;

public class Prescription
{
    public int PrescriptionId { get; set; }

    [Display(Name = "Пациент")]
    public int PatientId { get; set; }
    public Patient Patient { get; set; } = null!;

    [Display(Name = "Врач")]
    public int DoctorId { get; set; }
    public Doctor Doctor { get; set; } = null!;

    [Required(ErrorMessage = "Введите название препарата.")]
    [StringLength(150)]
    [Display(Name = "Препарат")]
    public string MedicationName { get; set; } = "";

    [Required(ErrorMessage = "Введите дозировку.")]
    [StringLength(100)]
    [Display(Name = "Дозировка")]
    public string Dosage { get; set; } = "";

    [Range(1, 365, ErrorMessage = "Длительность курса должна быть от 1 до 365 дней.")]
    [Display(Name = "Длительность (дней)")]
    public int Duration { get; set; }

    public static Prescription CreatePrescription(Patient patient, Doctor doctor, string medication, string dosage, int days)
    {
        var p = new Prescription { Patient = patient, Doctor = doctor };
        p.UpdatePrescription(medication, dosage, days);
        return p;
    }

    public void UpdatePrescription(string medication, string dosage, int days)
    {
        if (string.IsNullOrWhiteSpace(medication)) throw new ArgumentException("Название препарата не может быть пустым.");
        if (string.IsNullOrWhiteSpace(dosage)) throw new ArgumentException("Дозировка не может быть пустой.");
        if (days <= 0) throw new ArgumentException("Длительность курса должна быть положительной.");
        MedicationName = medication.Trim();
        Dosage = dosage.Trim();
        Duration = days;
    }

    public string DisplayPrescription() => $"{MedicationName}, {Dosage}, {Duration} дн.";
}
