using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MedicalPortal.Models;

public class Doctor : Person, IPayable
{
    public static readonly TimeSpan WorkStart = new(9, 0, 0);
    public static readonly TimeSpan WorkEnd = new(17, 0, 0);
    public static readonly TimeSpan SlotLength = new(1, 0, 0);

    [NotMapped]
    public int DoctorId => Id;

    [Required(ErrorMessage = "Введите специализацию.")]
    [StringLength(100)]
    [Display(Name = "Специализация")]
    public string Specialization { get; set; } = "";

    [Range(0, 70, ErrorMessage = "Стаж должен быть от 0 до 70 лет.")]
    [Display(Name = "Стаж (лет)")]
    public int Experience { get; set; }

    [Range(1, 9999, ErrorMessage = "Номер кабинета должен быть от 1 до 9999.")]
    [Display(Name = "Кабинет")]
    public int CabinetNumber { get; set; }

    [Range(0, 100000000, ErrorMessage = "Оклад не может быть отрицательным.")]
    [Display(Name = "Оклад")]
    public decimal Salary { get; set; }

    public List<Appointment> Appointments { get; set; } = new();
    public List<Prescription> Prescriptions { get; set; } = new();
    public List<Department> Departments { get; set; } = new();

    public void UpdateSpecialization(string newSpecialization)
    {
        if (string.IsNullOrWhiteSpace(newSpecialization))
            throw new ArgumentException("Специализация не может быть пустой.");
        Specialization = newSpecialization.Trim();
    }

    public decimal CalculateSalary()
    {
        decimal bonusPercent = Math.Min(Experience * 0.02m, 0.40m);
        return Math.Round(Salary * (1 + bonusPercent), 2);
    }

    public decimal CalculatePayment() => CalculateSalary();

    public bool IsSlotFree(DateTime start) =>
        !Appointments.Any(a => a.Status != AppointmentStatus.Cancelled && a.StartDateTime == start);

    public bool IsDoctorAvailable(DateTime date)
    {
        if (date.TimeOfDay != TimeSpan.Zero)
            return date.TimeOfDay >= WorkStart && date.TimeOfDay < WorkEnd && IsSlotFree(date);

        return GetFreeSlots(date).Any();
    }

    public List<TimeSpan> GetFreeSlots(DateTime date)
    {
        var result = new List<TimeSpan>();
        for (var t = WorkStart; t < WorkEnd; t += SlotLength)
            if (IsSlotFree(date.Date + t)) result.Add(t);
        return result;
    }

    public override string DisplayInfo() =>
        $"[{DoctorId}] {FullName}, {Specialization}, стаж {Experience} л., каб. {CabinetNumber}";
}
