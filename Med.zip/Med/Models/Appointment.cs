using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MedicalPortal.Models;

public class Appointment
{
    public int AppointmentId { get; set; }

    [Display(Name = "Пациент")]
    public int PatientId { get; set; }
    public Patient Patient { get; set; } = null!;

    [Display(Name = "Врач")]
    public int DoctorId { get; set; }
    public Doctor Doctor { get; set; } = null!;

    [Display(Name = "Дата")]
    [DataType(DataType.Date)]
    public DateTime AppointmentDate { get; set; }

    [Display(Name = "Время")]
    public TimeSpan AppointmentTime { get; set; }

    public AppointmentStatus Status { get; private set; } = AppointmentStatus.Scheduled;

    [NotMapped]
    public DateTime StartDateTime => AppointmentDate.Date + AppointmentTime;

    public static Appointment? CreateAppointment(Patient patient, Doctor doctor, DateTime date, TimeSpan time, out string? error)
    {
        error = null;
        var start = date.Date + time;

        if (date.Date == DateTime.MinValue.Date)
        {
            error = "Укажите дату приёма.";
            return null;
        }
        if (time < Doctor.WorkStart || time >= Doctor.WorkEnd)
        {
            error = $"Приём возможен только с {Doctor.WorkStart:hh\\:mm} до {Doctor.WorkEnd:hh\\:mm}.";
            return null;
        }
        if (start < DateTime.Now)
        {
            error = "Нельзя записаться на прошедшее время.";
            return null;
        }
        if (!doctor.IsDoctorAvailable(date.Date))
        {
            error = "На эту дату у врача нет свободного времени.";
            return null;
        }
        if (!doctor.IsSlotFree(start))
        {
            error = "Врач уже занят на указанное время!";
            return null;
        }

        return new Appointment
        {
            Patient = patient,
            PatientId = patient.Id,
            Doctor = doctor,
            DoctorId = doctor.Id,
            AppointmentDate = date.Date,
            AppointmentTime = time,
            Status = AppointmentStatus.Scheduled
        };
    }

    public string? ConfirmAppointment()
    {
        if (Status != AppointmentStatus.Scheduled)
            return $"Нельзя подтвердить запись со статусом «{Status.Name()}».";
        Status = AppointmentStatus.Confirmed;
        return null;
    }

    public string? CancelAppointment()
    {
        if (Status == AppointmentStatus.Completed || Status == AppointmentStatus.Cancelled)
            return $"Нельзя отменить запись со статусом «{Status.Name()}».";
        Status = AppointmentStatus.Cancelled;
        return null;
    }

    public string? CompleteAppointment()
    {
        if (Status != AppointmentStatus.Scheduled && Status != AppointmentStatus.Confirmed)
            return $"Нельзя завершить запись со статусом «{Status.Name()}».";
        Status = AppointmentStatus.Completed;
        return null;
    }

    public string DisplayAppointment() =>
        $"№{AppointmentId}: {AppointmentDate:dd.MM.yyyy} {AppointmentTime:hh\\:mm}, {Patient?.FullName} → {Doctor?.FullName}, {Status.Name()}";
}
