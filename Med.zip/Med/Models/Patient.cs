using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MedicalPortal.Models;

public class Patient : Person
{
    [NotMapped]
    public int PatientId => Id;

    [Required(ErrorMessage = "Введите номер телефона.")]
    [StringLength(30)]
    [Display(Name = "Телефон")]
    public string PhoneNumber { get; set; } = "";

    [Required(ErrorMessage = "Введите email.")]
    [EmailAddress(ErrorMessage = "Некорректный email.")]
    [Display(Name = "Email")]
    public string Email { get; set; } = "";

    [Required(ErrorMessage = "Введите адрес.")]
    [StringLength(250)]
    [Display(Name = "Адрес")]
    public string Address { get; set; } = "";

    public List<Appointment> Appointments { get; set; } = new();
    public List<MedicalTest> Tests { get; set; } = new();
    public List<Prescription> Prescriptions { get; set; } = new();
    public List<Payment> Payments { get; set; } = new();

    public MedicalRecord? Record { get; set; }

    public void EnsureRecord()
    {
        Record ??= new MedicalRecord { CreationDate = DateTime.Now };
    }

    public void UpdateProfile(string fullName, string phone, string email, string address)
    {
        if (string.IsNullOrWhiteSpace(fullName)) throw new ArgumentException("ФИО не может быть пустым.");
        if (string.IsNullOrWhiteSpace(phone)) throw new ArgumentException("Телефон не может быть пустым.");
        if (string.IsNullOrWhiteSpace(email)) throw new ArgumentException("Email не может быть пустым.");
        if (string.IsNullOrWhiteSpace(address)) throw new ArgumentException("Адрес не может быть пустым.");
        FullName = fullName.Trim();
        PhoneNumber = phone.Trim();
        Email = email.Trim();
        Address = address.Trim();
    }

    public override string DisplayInfo() =>
        $"[{PatientId}] {FullName}, {GetAge()} лет, тел.: {PhoneNumber}, email: {Email}, адрес: {Address}";
}
