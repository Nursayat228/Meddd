using System.ComponentModel.DataAnnotations;

namespace MedicalPortal.Models;

public class NotFutureDateAttribute : ValidationAttribute
{
    public NotFutureDateAttribute()
    {
        ErrorMessage = "Укажите корректную дату рождения (не в будущем).";
    }

    public override bool IsValid(object? value)
    {
        return value is DateTime d && d.Date <= DateTime.Today && d.Year >= 1900;
    }
}
