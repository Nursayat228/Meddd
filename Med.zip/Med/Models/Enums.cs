namespace MedicalPortal.Models;

public enum AppointmentStatus
{
    Scheduled,
    Confirmed,
    Completed,
    Cancelled
}

public enum PaymentStatus
{
    Pending,
    Paid,
    Refunded
}

public static class RuNames
{
    public static string Name(this AppointmentStatus s) => s switch
    {
        AppointmentStatus.Scheduled => "Запланирована",
        AppointmentStatus.Confirmed => "Подтверждена",
        AppointmentStatus.Completed => "Завершена",
        AppointmentStatus.Cancelled => "Отменена",
        _ => s.ToString()
    };

    public static string Name(this PaymentStatus s) => s switch
    {
        PaymentStatus.Pending => "Ожидает оплаты",
        PaymentStatus.Paid => "Оплачен",
        PaymentStatus.Refunded => "Возвращён",
        _ => s.ToString()
    };
}
