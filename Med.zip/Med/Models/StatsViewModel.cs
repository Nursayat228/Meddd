namespace MedicalPortal.Models;

public class StatsViewModel
{
    public int PatientsCount { get; set; }
    public int DoctorsCount { get; set; }
    public int AppointmentsCount { get; set; }
    public int CompletedCount { get; set; }
    public decimal TotalPaid { get; set; }
}
