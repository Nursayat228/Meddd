using System.ComponentModel.DataAnnotations;

namespace MedicalPortal.Models;

public class MedicalService
{
    public int ServiceId { get; set; }

    [Required(ErrorMessage = "Введите название услуги.")]
    [StringLength(150)]
    [Display(Name = "Название")]
    public string ServiceName { get; set; } = "";

    [StringLength(500)]
    [Display(Name = "Описание")]
    public string? Description { get; set; }

    [Range(0, 100000000, ErrorMessage = "Стоимость услуги не может быть меньше нуля.")]
    [Display(Name = "Стоимость")]
    public decimal Price { get; set; }

    [Range(1, 600, ErrorMessage = "Длительность должна быть от 1 до 600 минут.")]
    [Display(Name = "Длительность (мин)")]
    public int Duration { get; set; }

    public decimal CalculatePrice(int quantity = 1, decimal discountPercent = 0)
    {
        if (quantity <= 0) throw new ArgumentException("Количество должно быть положительным.");
        if (discountPercent < 0 || discountPercent > 100) throw new ArgumentException("Скидка должна быть от 0 до 100%.");
        return Math.Round(Price * quantity * (1 - discountPercent / 100m), 2);
    }

    public void UpdatePrice(decimal newPrice)
    {
        if (newPrice < 0) throw new ArgumentException("Стоимость услуги не может быть меньше нуля.");
        Price = newPrice;
    }

    public string DisplayService() => $"{ServiceName} — {Price:N2} ₸, {Duration} мин.";
}
