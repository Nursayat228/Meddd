using System.ComponentModel.DataAnnotations;

namespace MedicalPortal.Models;

public abstract class Person
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Введите ФИО.")]
    [StringLength(150, ErrorMessage = "ФИО слишком длинное.")]
    [Display(Name = "ФИО")]
    public string FullName { get; set; } = "";

    [Display(Name = "Дата рождения")]
    [DataType(DataType.Date)]
    [NotFutureDate]
    public DateTime BirthDate { get; set; }

    public int GetAge()
    {
        var today = DateTime.Today;
        int age = today.Year - BirthDate.Year;
        if (BirthDate.Date > today.AddYears(-age)) age--;
        return age;
    }

    public abstract string DisplayInfo();
}
