using System.ComponentModel.DataAnnotations;

namespace MedicalPortal.Models;

public class MedicalTest
{
    public int TestId { get; set; }

    [Display(Name = "Пациент")]
    public int PatientId { get; set; }
    public Patient Patient { get; set; } = null!;

    [Required(ErrorMessage = "Введите название анализа.")]
    [StringLength(150)]
    [Display(Name = "Анализ")]
    public string TestName { get; set; } = "";

    [Display(Name = "Дата")]
    [DataType(DataType.Date)]
    public DateTime TestDate { get; set; }

    [Display(Name = "Результат")]
    public string? Result { get; set; }

    public void AddResult(string result)
    {
        if (string.IsNullOrWhiteSpace(result)) throw new ArgumentException("Результат не может быть пустым.");
        Result = result.Trim();
    }

    public void UpdateResult(string result)
    {
        if (string.IsNullOrWhiteSpace(Result)) throw new ArgumentException("Результат ещё не внесён.");
        AddResult(result);
    }

    public string DisplayResult() => string.IsNullOrWhiteSpace(Result) ? "ожидается" : Result;
}
