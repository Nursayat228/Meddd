using System.ComponentModel.DataAnnotations;

namespace MedicalPortal.Models;

public class Department
{
    public int DepartmentId { get; set; }

    [Required(ErrorMessage = "Введите название отделения.")]
    [StringLength(100)]
    [Display(Name = "Название")]
    public string DepartmentName { get; set; } = "";

    [Range(0, 100, ErrorMessage = "Этаж должен быть от 0 до 100.")]
    [Display(Name = "Этаж")]
    public int Floor { get; set; }

    [Required(ErrorMessage = "Введите телефон отделения.")]
    [StringLength(30)]
    [Display(Name = "Телефон")]
    public string PhoneNumber { get; set; } = "";

    [Display(Name = "Заведующий")]
    public int? HeadDoctorId { get; set; }
    public Doctor? HeadDoctor { get; set; }

    public List<Doctor> Doctors { get; set; } = new();

    public bool AddDoctor(Doctor doctor)
    {
        if (Doctors.Any(d => d.Id == doctor.Id)) return false;
        Doctors.Add(doctor);
        return true;
    }

    public bool RemoveDoctor(Doctor doctor)
    {
        var existing = Doctors.FirstOrDefault(d => d.Id == doctor.Id);
        if (existing == null) return false;
        if (HeadDoctorId == doctor.Id)
        {
            HeadDoctor = null;
            HeadDoctorId = null;
        }
        return Doctors.Remove(existing);
    }

    public string DisplayDoctors() =>
        Doctors.Count == 0 ? "Врачей нет" : string.Join(", ", Doctors.Select(d => d.FullName));
}
