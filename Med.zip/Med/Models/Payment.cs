using System.ComponentModel.DataAnnotations;

namespace MedicalPortal.Models;

public class Payment : IPayable
{
    public int PaymentId { get; set; }

    [Display(Name = "Пациент")]
    public int PatientId { get; set; }
    public Patient Patient { get; set; } = null!;

    [Display(Name = "Услуга")]
    public int? ServiceId { get; set; }
    public MedicalService? Service { get; set; }

    [Range(0, 100000000, ErrorMessage = "Сумма не может быть отрицательной.")]
    public decimal Amount { get; set; }

    public DateTime PaymentDate { get; set; }

    public PaymentStatus PaymentStatus { get; private set; } = PaymentStatus.Pending;

    public decimal CalculatePayment() => Amount;

    public string? MakePayment()
    {
        if (PaymentStatus != PaymentStatus.Pending)
            return $"Платёж уже обработан (статус: {RuNames.Name(PaymentStatus)}).";
        PaymentStatus = PaymentStatus.Paid;
        PaymentDate = DateTime.Now;
        return null;
    }

    public string? RefundPayment()
    {
        if (PaymentStatus != PaymentStatus.Paid)
            return "Вернуть можно только оплаченный платёж.";
        PaymentStatus = PaymentStatus.Refunded;
        return null;
    }

    public string DisplayPayment() => $"№{PaymentId}: {Amount:N2} ₸, {RuNames.Name(PaymentStatus)}";
}
