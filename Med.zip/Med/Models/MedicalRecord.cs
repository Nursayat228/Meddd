namespace MedicalPortal.Models;

public class MedicalRecord
{
    public int RecordId { get; set; }

    public int PatientId { get; set; }
    public Patient Patient { get; set; } = null!;

    public string Diagnosis { get; set; } = "не установлен";
    public string MedicalHistory { get; set; } = "";
    public DateTime CreationDate { get; set; }

    public void AddDiagnosis(string diagnosis)
    {
        if (string.IsNullOrWhiteSpace(diagnosis)) throw new ArgumentException("Диагноз не может быть пустым.");
        Diagnosis = diagnosis.Trim();
        UpdateHistory($"Установлен диагноз: {Diagnosis}");
    }

    public void UpdateHistory(string entry)
    {
        if (string.IsNullOrWhiteSpace(entry)) throw new ArgumentException("Запись не может быть пустой.");
        MedicalHistory += $"[{DateTime.Now:dd.MM.yyyy}] {entry.Trim()}\n";
    }

    public string DisplayRecord() => $"Медкарта №{RecordId}: диагноз — {Diagnosis}";
}
