using MedicalPortal.Models;

namespace MedicalPortal.Data;

public static class SeedData
{
    public static void Fill(PortalContext db)
    {
        if (db.Doctors.Any() || db.Patients.Any() || db.MedicalServices.Any())
            return;

        var d1 = new Doctor { FullName = "Иванов Сергей Петрович", BirthDate = new DateTime(1980, 3, 12), Specialization = "Терапевт", Experience = 15, CabinetNumber = 101, Salary = 300000m };
        var d2 = new Doctor { FullName = "Смагулова Айгуль Нуровна", BirthDate = new DateTime(1987, 7, 25), Specialization = "Кардиолог", Experience = 9, CabinetNumber = 204, Salary = 380000m };
        var d3 = new Doctor { FullName = "Ким Дмитрий Андреевич", BirthDate = new DateTime(1990, 11, 2), Specialization = "Невролог", Experience = 5, CabinetNumber = 305, Salary = 350000m };
        db.Doctors.AddRange(d1, d2, d3);

        var p1 = new Patient { FullName = "Алиев Расул Маратович", BirthDate = new DateTime(1992, 5, 14), PhoneNumber = "+7 701 111 22 33", Email = "rasul@mail.kz", Address = "г. Астана, ул. Абая 10" };
        var p2 = new Patient { FullName = "Петрова Мария Ивановна", BirthDate = new DateTime(1975, 9, 3), PhoneNumber = "+7 702 444 55 66", Email = "maria@mail.ru", Address = "г. Астана, пр. Мангилик Ел 5" };
        p1.EnsureRecord();
        p2.EnsureRecord();
        db.Patients.AddRange(p1, p2);

        var s1 = new MedicalService { ServiceName = "Консультация терапевта", Description = "Первичный приём", Price = 8000m, Duration = 30 };
        var s2 = new MedicalService { ServiceName = "ЭКГ", Description = "Электрокардиография", Price = 6000m, Duration = 20 };
        var s3 = new MedicalService { ServiceName = "Общий анализ крови", Description = "Лабораторное исследование", Price = 3500m, Duration = 15 };
        db.MedicalServices.AddRange(s1, s2, s3);

        var therapy = new Department { DepartmentName = "Терапия", Floor = 1, PhoneNumber = "+7 7172 11-22-33", HeadDoctor = d1 };
        therapy.AddDoctor(d1);
        var cardio = new Department { DepartmentName = "Кардиология", Floor = 2, PhoneNumber = "+7 7172 11-22-44", HeadDoctor = d2 };
        cardio.AddDoctor(d2);
        cardio.AddDoctor(d3);
        db.Departments.AddRange(therapy, cardio);

        db.SaveChanges();

        var tomorrow = DateTime.Today.AddDays(1);

        var a1 = Appointment.CreateAppointment(p1, d1, tomorrow, new TimeSpan(10, 0, 0), out _);
        if (a1 != null)
        {
            a1.ConfirmAppointment();
            a1.CompleteAppointment();
            db.Appointments.Add(a1);
        }

        var a2 = Appointment.CreateAppointment(p2, d2, tomorrow, new TimeSpan(11, 0, 0), out _);
        if (a2 != null) db.Appointments.Add(a2);

        p1.Record!.AddDiagnosis("ОРВИ");

        var pay = new Payment { Patient = p1, Service = s1, Amount = s1.CalculatePrice(), PaymentDate = DateTime.Now };
        pay.MakePayment();
        db.Payments.Add(pay);

        db.SaveChanges();
    }
}
