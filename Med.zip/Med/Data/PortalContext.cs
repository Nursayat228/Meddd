using MedicalPortal.Models;
using Microsoft.EntityFrameworkCore;

namespace MedicalPortal.Data;

public class PortalContext : DbContext
{
    public PortalContext(DbContextOptions<PortalContext> options) : base(options)
    {
    }

    public DbSet<Patient> Patients => Set<Patient>();
    public DbSet<Doctor> Doctors => Set<Doctor>();
    public DbSet<Department> Departments => Set<Department>();
    public DbSet<Appointment> Appointments => Set<Appointment>();
    public DbSet<MedicalRecord> MedicalRecords => Set<MedicalRecord>();
    public DbSet<MedicalTest> MedicalTests => Set<MedicalTest>();
    public DbSet<Prescription> Prescriptions => Set<Prescription>();
    public DbSet<MedicalService> MedicalServices => Set<MedicalService>();
    public DbSet<Payment> Payments => Set<Payment>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<Person>();

        b.Entity<Department>().HasKey(d => d.DepartmentId);
        b.Entity<Department>()
            .HasMany(d => d.Doctors)
            .WithMany(d => d.Departments);
        b.Entity<Department>()
            .HasOne(d => d.HeadDoctor)
            .WithMany()
            .HasForeignKey(d => d.HeadDoctorId)
            .OnDelete(DeleteBehavior.SetNull);

        b.Entity<MedicalRecord>().HasKey(r => r.RecordId);
        b.Entity<Patient>()
            .HasOne(p => p.Record)
            .WithOne(r => r.Patient)
            .HasForeignKey<MedicalRecord>(r => r.PatientId)
            .OnDelete(DeleteBehavior.Cascade);

        b.Entity<Appointment>().HasKey(a => a.AppointmentId);
        b.Entity<Appointment>()
            .HasOne(a => a.Patient)
            .WithMany(p => p.Appointments)
            .HasForeignKey(a => a.PatientId)
            .OnDelete(DeleteBehavior.Cascade);
        b.Entity<Appointment>()
            .HasOne(a => a.Doctor)
            .WithMany(d => d.Appointments)
            .HasForeignKey(a => a.DoctorId)
            .OnDelete(DeleteBehavior.Cascade);

        b.Entity<MedicalTest>().HasKey(t => t.TestId);
        b.Entity<MedicalTest>()
            .HasOne(t => t.Patient)
            .WithMany(p => p.Tests)
            .HasForeignKey(t => t.PatientId)
            .OnDelete(DeleteBehavior.Cascade);

        b.Entity<Prescription>().HasKey(p => p.PrescriptionId);
        b.Entity<Prescription>()
            .HasOne(p => p.Patient)
            .WithMany(p => p.Prescriptions)
            .HasForeignKey(p => p.PatientId)
            .OnDelete(DeleteBehavior.Cascade);
        b.Entity<Prescription>()
            .HasOne(p => p.Doctor)
            .WithMany(d => d.Prescriptions)
            .HasForeignKey(p => p.DoctorId)
            .OnDelete(DeleteBehavior.Cascade);

        b.Entity<MedicalService>().HasKey(s => s.ServiceId);

        b.Entity<Payment>().HasKey(p => p.PaymentId);
        b.Entity<Payment>()
            .HasOne(p => p.Patient)
            .WithMany(p => p.Payments)
            .HasForeignKey(p => p.PatientId)
            .OnDelete(DeleteBehavior.Cascade);
        b.Entity<Payment>()
            .HasOne(p => p.Service)
            .WithMany()
            .HasForeignKey(p => p.ServiceId)
            .OnDelete(DeleteBehavior.SetNull);
    }
}
