using MedicalPortal.Data;
using MedicalPortal.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace MedicalPortal.Controllers;

public class AppointmentsController : Controller
{
    private readonly PortalContext _db;

    public AppointmentsController(PortalContext db)
    {
        _db = db;
    }

    public IActionResult Index()
    {
        var list = _db.Appointments
            .Include(a => a.Patient)
            .Include(a => a.Doctor)
            .ToList()
            .OrderBy(a => a.StartDateTime)
            .ToList();
        return View(list);
    }

    public IActionResult Create(int? patientId, int? doctorId)
    {
        FillLists();
        var model = new Appointment
        {
            AppointmentDate = DateTime.Today.AddDays(1),
            AppointmentTime = Doctor.WorkStart,
            PatientId = patientId ?? 0,
            DoctorId = doctorId ?? 0
        };
        return View(model);
    }

    [HttpPost]
    public IActionResult Create([Bind("PatientId,DoctorId,AppointmentDate,AppointmentTime")] Appointment model)
    {
        var patient = _db.Patients.FirstOrDefault(p => p.Id == model.PatientId);
        var doctor = _db.Doctors.Include(d => d.Appointments).FirstOrDefault(d => d.Id == model.DoctorId);

        if (patient == null || doctor == null)
        {
            ModelState.AddModelError("", "Выберите пациента и врача.");
            FillLists();
            return View(model);
        }

        var appointment = Appointment.CreateAppointment(patient, doctor, model.AppointmentDate, model.AppointmentTime, out var error);
        if (appointment == null)
        {
            ModelState.AddModelError("", error ?? "Не удалось создать запись.");
            FillLists();
            return View(model);
        }

        _db.Appointments.Add(appointment);
        _db.SaveChanges();
        TempData["Message"] = "Запись на приём создана.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public IActionResult Confirm(int id) => Change(id, a => a.ConfirmAppointment(), "Запись подтверждена.");

    [HttpPost]
    public IActionResult Cancel(int id) => Change(id, a => a.CancelAppointment(), "Запись отменена, время врача освобождено.");

    [HttpPost]
    public IActionResult Complete(int id) => Change(id, a => a.CompleteAppointment(), "Приём завершён.");

    private IActionResult Change(int id, Func<Appointment, string?> action, string successMessage)
    {
        var appointment = _db.Appointments.FirstOrDefault(a => a.AppointmentId == id);
        if (appointment == null) return NotFound();

        var error = action(appointment);
        if (error != null)
        {
            TempData["Error"] = error;
        }
        else
        {
            _db.SaveChanges();
            TempData["Message"] = successMessage;
        }

        return RedirectToAction(nameof(Index));
    }

    private void FillLists()
    {
        ViewBag.Patients = new SelectList(_db.Patients.ToList().OrderBy(p => p.FullName).ToList(), "Id", "FullName");
        ViewBag.Doctors = new SelectList(
            _db.Doctors.ToList().OrderBy(d => d.FullName).Select(d => new { d.Id, Name = d.FullName + " — " + d.Specialization }).ToList(),
            "Id", "Name");

        var slots = new List<SelectListItem>();
        for (var t = Doctor.WorkStart; t < Doctor.WorkEnd; t += Doctor.SlotLength)
            slots.Add(new SelectListItem(t.ToString(@"hh\:mm"), t.ToString(@"hh\:mm\:ss")));
        ViewBag.Slots = slots;
    }
}
