using MedicalPortal.Data;
using MedicalPortal.Models;
using Microsoft.AspNetCore.Mvc;

namespace MedicalPortal.Controllers;

public class ServicesController : Controller
{
    private readonly PortalContext _db;

    public ServicesController(PortalContext db)
    {
        _db = db;
    }

    public IActionResult Index()
    {
        return View(_db.MedicalServices.ToList().OrderBy(s => s.ServiceName).ToList());
    }

    [HttpPost]
    public IActionResult Create([Bind("ServiceName,Description,Price,Duration")] MedicalService service)
    {
        if (!ModelState.IsValid)
        {
            TempData["Error"] = string.Join(" ", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
            return RedirectToAction(nameof(Index));
        }

        _db.MedicalServices.Add(service);
        _db.SaveChanges();
        TempData["Message"] = "Услуга добавлена.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public IActionResult UpdatePrice(int id, decimal price)
    {
        var service = _db.MedicalServices.FirstOrDefault(s => s.ServiceId == id);
        if (service == null) return NotFound();

        try
        {
            service.UpdatePrice(price);
            _db.SaveChanges();
            TempData["Message"] = "Стоимость обновлена.";
        }
        catch (ArgumentException ex)
        {
            TempData["Error"] = ex.Message;
        }

        return RedirectToAction(nameof(Index));
    }
}
