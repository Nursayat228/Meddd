using MedicalPortal.Data;
using MedicalPortal.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace MedicalPortal.Controllers;

public class DoctorsController : Controller
{
    private readonly PortalContext _db;

    public DoctorsController(PortalContext db)
    {
        _db = db;
    }

    public IActionResult Index()
    {
        var list = _db.Doctors.ToList().OrderBy(d => d.FullName).ToList();
        return View(list);
    }

    public IActionResult Create()
    {
        return View(new Doctor { BirthDate = new DateTime(1985, 1, 1), CabinetNumber = 100 });
    }

    [HttpPost]
    public IActionResult Create([Bind("FullName,BirthDate,Specialization,Experience,CabinetNumber,Salary")] Doctor doctor)
    {
        if (!ModelState.IsValid) return View(doctor);

        _db.Doctors.Add(doctor);
        _db.SaveChanges();
        TempData["Message"] = "Врач добавлен.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public IActionResult UpdateSpecialization(int id, string specialization)
    {
        var doctor = _db.Doctors.FirstOrDefault(d => d.Id == id);
        if (doctor == null) return NotFound();

        try
        {
            doctor.UpdateSpecialization(specialization);
            _db.SaveChanges();
            TempData["Message"] = "Специализация обновлена.";
        }
        catch (ArgumentException ex)
        {
            TempData["Error"] = ex.Message;
        }

        return RedirectToAction(nameof(Index));
    }

    public IActionResult Schedule(int id, DateTime? date)
    {
        var doctor = _db.Doctors
            .Include(d => d.Appointments).ThenInclude(a => a.Patient)
            .FirstOrDefault(d => d.Id == id);
        if (doctor == null) return NotFound();

        var day = (date ?? DateTime.Today).Date;
        ViewBag.Date = day;
        ViewBag.FreeSlots = doctor.GetFreeSlots(day);
        ViewBag.DayAppointments = doctor.Appointments
            .Where(a => a.AppointmentDate.Date == day && a.Status != AppointmentStatus.Cancelled)
            .OrderBy(a => a.AppointmentTime)
            .ToList();
        return View(doctor);
    }
}
