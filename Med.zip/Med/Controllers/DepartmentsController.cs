using MedicalPortal.Data;
using MedicalPortal.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace MedicalPortal.Controllers;

public class DepartmentsController : Controller
{
    private readonly PortalContext _db;

    public DepartmentsController(PortalContext db)
    {
        _db = db;
    }

    public IActionResult Index()
    {
        FillLists();
        var list = _db.Departments
            .Include(d => d.Doctors)
            .Include(d => d.HeadDoctor)
            .ToList();
        return View(list);
    }

    [HttpPost]
    public IActionResult Create([Bind("DepartmentName,Floor,PhoneNumber,HeadDoctorId")] Department department)
    {
        if (!ModelState.IsValid)
        {
            TempData["Error"] = string.Join(" ", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
            return RedirectToAction(nameof(Index));
        }

        if (department.HeadDoctorId.HasValue)
        {
            var head = _db.Doctors.FirstOrDefault(d => d.Id == department.HeadDoctorId.Value);
            if (head == null)
            {
                department.HeadDoctorId = null;
            }
            else
            {
                department.AddDoctor(head);
            }
        }

        _db.Departments.Add(department);
        _db.SaveChanges();
        TempData["Message"] = "Отделение создано.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public IActionResult AddDoctor(int departmentId, int doctorId)
    {
        var department = _db.Departments.Include(d => d.Doctors).FirstOrDefault(d => d.DepartmentId == departmentId);
        var doctor = _db.Doctors.FirstOrDefault(d => d.Id == doctorId);
        if (department == null || doctor == null)
        {
            TempData["Error"] = "Отделение или врач не найдены.";
            return RedirectToAction(nameof(Index));
        }

        if (department.AddDoctor(doctor))
        {
            _db.SaveChanges();
            TempData["Message"] = "Врач добавлен в отделение.";
        }
        else
        {
            TempData["Error"] = "Этот врач уже работает в отделении.";
        }

        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public IActionResult RemoveDoctor(int departmentId, int doctorId)
    {
        var department = _db.Departments.Include(d => d.Doctors).FirstOrDefault(d => d.DepartmentId == departmentId);
        var doctor = department?.Doctors.FirstOrDefault(d => d.Id == doctorId);
        if (department == null || doctor == null)
        {
            TempData["Error"] = "Врач в отделении не найден.";
            return RedirectToAction(nameof(Index));
        }

        department.RemoveDoctor(doctor);
        _db.SaveChanges();
        TempData["Message"] = "Врач убран из отделения. Сам врач остаётся в системе.";
        return RedirectToAction(nameof(Index));
    }

    private void FillLists()
    {
        ViewBag.Doctors = new SelectList(_db.Doctors.ToList().OrderBy(d => d.FullName).ToList(), "Id", "FullName");
    }
}
