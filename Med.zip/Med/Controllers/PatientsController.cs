using MedicalPortal.Data;
using MedicalPortal.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace MedicalPortal.Controllers;

public class PatientsController : Controller
{
    private readonly PortalContext _db;

    public PatientsController(PortalContext db)
    {
        _db = db;
    }

    public IActionResult Index(string? searchBy, string? q)
    {
        var list = _db.Patients.ToList().OrderBy(p => p.FullName).ToList();

        if (!string.IsNullOrWhiteSpace(q))
        {
            q = q.Trim();
            switch (searchBy)
            {
                case "id":
                    list = int.TryParse(q, out var id)
                        ? list.Where(p => p.Id == id).ToList()
                        : new List<Patient>();
                    break;
                case "phone":
                    var digits = new string(q.Where(char.IsDigit).ToArray());
                    list = digits.Length == 0
                        ? new List<Patient>()
                        : list.Where(p => new string(p.PhoneNumber.Where(char.IsDigit).ToArray()).Contains(digits)).ToList();
                    break;
                default:
                    list = list.Where(p => p.FullName.Contains(q, StringComparison.OrdinalIgnoreCase)).ToList();
                    break;
            }

            if (list.Count == 0)
                ViewBag.Message = "Пациент не найден. Проверьте введённые данные.";
        }

        ViewBag.SearchBy = searchBy ?? "name";
        ViewBag.Query = q;
        return View(list);
    }

    public IActionResult Create()
    {
        return View(new Patient { BirthDate = new DateTime(2000, 1, 1) });
    }

    [HttpPost]
    public IActionResult Create([Bind("FullName,BirthDate,PhoneNumber,Email,Address")] Patient patient)
    {
        if (!ModelState.IsValid) return View(patient);

        patient.EnsureRecord();
        _db.Patients.Add(patient);
        _db.SaveChanges();
        TempData["Message"] = "Пациент добавлен.";
        return RedirectToAction(nameof(Details), new { id = patient.Id });
    }

    public IActionResult Details(int id)
    {
        var patient = _db.Patients
            .Include(p => p.Record)
            .Include(p => p.Appointments).ThenInclude(a => a.Doctor)
            .Include(p => p.Tests)
            .Include(p => p.Prescriptions).ThenInclude(r => r.Doctor)
            .Include(p => p.Payments).ThenInclude(x => x.Service)
            .FirstOrDefault(p => p.Id == id);

        if (patient == null) return NotFound();
        return View(patient);
    }

    public IActionResult Edit(int id)
    {
        var patient = _db.Patients.FirstOrDefault(p => p.Id == id);
        if (patient == null) return NotFound();
        return View(patient);
    }

    [HttpPost]
    public IActionResult Edit(int id, [Bind("FullName,BirthDate,PhoneNumber,Email,Address")] Patient model)
    {
        var patient = _db.Patients.FirstOrDefault(p => p.Id == id);
        if (patient == null) return NotFound();

        if (!ModelState.IsValid)
        {
            model.Id = id;
            return View(model);
        }

        try
        {
            patient.UpdateProfile(model.FullName, model.PhoneNumber, model.Email, model.Address);
            patient.BirthDate = model.BirthDate;
            _db.SaveChanges();
        }
        catch (ArgumentException ex)
        {
            ModelState.AddModelError("", ex.Message);
            model.Id = id;
            return View(model);
        }

        TempData["Message"] = "Данные пациента обновлены.";
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost]
    public IActionResult UpdateRecord(int id, string? diagnosis, string? entry)
    {
        var patient = _db.Patients.Include(p => p.Record).FirstOrDefault(p => p.Id == id);
        if (patient == null) return NotFound();

        try
        {
            patient.EnsureRecord();
            if (!string.IsNullOrWhiteSpace(diagnosis)) patient.Record!.AddDiagnosis(diagnosis);
            if (!string.IsNullOrWhiteSpace(entry)) patient.Record!.UpdateHistory(entry);
            if (string.IsNullOrWhiteSpace(diagnosis) && string.IsNullOrWhiteSpace(entry))
                throw new ArgumentException("Введите диагноз или запись в историю болезни.");
            _db.SaveChanges();
            TempData["Message"] = "Медицинская карта обновлена.";
        }
        catch (ArgumentException ex)
        {
            TempData["Error"] = ex.Message;
        }

        return RedirectToAction(nameof(Details), new { id });
    }
}
