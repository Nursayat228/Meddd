using MedicalPortal.Data;
using MedicalPortal.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace MedicalPortal.Controllers;

public class TestsController : Controller
{
    private readonly PortalContext _db;

    public TestsController(PortalContext db)
    {
        _db = db;
    }

    public IActionResult Index()
    {
        var list = _db.MedicalTests.Include(t => t.Patient).ToList().OrderByDescending(t => t.TestDate).ToList();
        return View(list);
    }

    public IActionResult Create(int? patientId)
    {
        FillLists();
        return View(new MedicalTest { TestDate = DateTime.Today, PatientId = patientId ?? 0 });
    }

    [HttpPost]
    public IActionResult Create([Bind("PatientId,TestName,TestDate,Result")] MedicalTest test)
    {
        if (!ModelState.IsValid || !_db.Patients.Any(p => p.Id == test.PatientId))
        {
            if (ModelState.IsValid) ModelState.AddModelError("", "Выберите пациента.");
            FillLists();
            return View(test);
        }

        var result = test.Result;
        test.Result = null;
        if (!string.IsNullOrWhiteSpace(result)) test.AddResult(result);

        _db.MedicalTests.Add(test);
        _db.SaveChanges();
        TempData["Message"] = "Анализ добавлен.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public IActionResult SaveResult(int id, string result)
    {
        var test = _db.MedicalTests.FirstOrDefault(t => t.TestId == id);
        if (test == null) return NotFound();

        try
        {
            if (string.IsNullOrWhiteSpace(test.Result)) test.AddResult(result);
            else test.UpdateResult(result);
            _db.SaveChanges();
            TempData["Message"] = "Результат сохранён.";
        }
        catch (ArgumentException ex)
        {
            TempData["Error"] = ex.Message;
        }

        return RedirectToAction(nameof(Index));
    }

    private void FillLists()
    {
        ViewBag.Patients = new SelectList(_db.Patients.ToList().OrderBy(p => p.FullName).ToList(), "Id", "FullName");
    }
}
