using MedicalPortal.Data;
using MedicalPortal.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace MedicalPortal.Controllers;

public class PaymentsController : Controller
{
    private readonly PortalContext _db;

    public PaymentsController(PortalContext db)
    {
        _db = db;
    }

    public IActionResult Index()
    {
        var list = _db.Payments
            .Include(p => p.Patient)
            .Include(p => p.Service)
            .ToList()
            .OrderByDescending(p => p.PaymentDate)
            .ToList();
        return View(list);
    }

    public IActionResult Create(int? patientId)
    {
        FillLists();
        ViewBag.Quantity = 1;
        return View(new Payment { PatientId = patientId ?? 0 });
    }

    [HttpPost]
    public IActionResult Create(int patientId, int serviceId, int quantity = 1)
    {
        var patient = _db.Patients.FirstOrDefault(p => p.Id == patientId);
        var service = _db.MedicalServices.FirstOrDefault(s => s.ServiceId == serviceId);

        if (patient == null || service == null)
        {
            ModelState.AddModelError("", "Выберите пациента и услугу.");
            FillLists();
            ViewBag.Quantity = quantity;
            return View(new Payment { PatientId = patientId, ServiceId = serviceId });
        }

        try
        {
            var payment = new Payment
            {
                Patient = patient,
                Service = service,
                Amount = service.CalculatePrice(quantity),
                PaymentDate = DateTime.Now
            };
            payment.MakePayment();
            _db.Payments.Add(payment);
            _db.SaveChanges();
            TempData["Message"] = $"Оплата принята: {payment.Amount:N2} ₸.";
        }
        catch (ArgumentException ex)
        {
            ModelState.AddModelError("", ex.Message);
            FillLists();
            ViewBag.Quantity = quantity;
            return View(new Payment { PatientId = patientId, ServiceId = serviceId });
        }

        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public IActionResult Refund(int id)
    {
        var payment = _db.Payments.FirstOrDefault(p => p.PaymentId == id);
        if (payment == null) return NotFound();

        var error = payment.RefundPayment();
        if (error != null)
        {
            TempData["Error"] = error;
        }
        else
        {
            _db.SaveChanges();
            TempData["Message"] = "Платёж возвращён.";
        }

        return RedirectToAction(nameof(Index));
    }

    private void FillLists()
    {
        ViewBag.Patients = new SelectList(_db.Patients.ToList().OrderBy(p => p.FullName).ToList(), "Id", "FullName");
        ViewBag.Services = new SelectList(
            _db.MedicalServices.ToList().OrderBy(s => s.ServiceName).Select(s => new { s.ServiceId, Name = s.ServiceName + " — " + s.Price.ToString("N2") + " ₸" }).ToList(),
            "ServiceId", "Name");
    }
}
