using MedicalPortal.Data;
using MedicalPortal.Models;
using Microsoft.AspNetCore.Mvc;

namespace MedicalPortal.Controllers;

public class HomeController : Controller
{
    private readonly PortalContext _db;

    public HomeController(PortalContext db)
    {
        _db = db;
    }

    public IActionResult Index()
    {
        var paidPayments = _db.Payments.ToList()
            .Where(p => p.PaymentStatus == PaymentStatus.Paid)
            .ToList();

        var vm = new StatsViewModel
        {
            PatientsCount = _db.Patients.Count(),
            DoctorsCount = _db.Doctors.Count(),
            AppointmentsCount = _db.Appointments.Count(),
            CompletedCount = _db.Appointments.Count(a => a.Status == AppointmentStatus.Completed),
            TotalPaid = paidPayments.Sum(p => p.Amount)
        };
        return View(vm);
    }

    public IActionResult Error()
    {
        return Content("Произошла ошибка. Вернитесь на главную страницу.");
    }
}
