using MedicalPortal.Data;
using MedicalPortal.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace MedicalPortal.Controllers;

public class PrescriptionsController : Controller
{
    private readonly PortalContext _db;

    public PrescriptionsController(PortalContext db)
    {
        _db = db;
    }

    public IActionResult Index()
    {
        var list = _db.Prescriptions.Include(p => p.Patient).Include(p => p.Doctor).ToList();
        return View(list);
    }

    public IActionResult Create(int? patientId)
    {
        FillLists();
        return View(new Prescription { PatientId = patientId ?? 0, Duration = 7 });
    }

    [HttpPost]
    public IActionResult Create([Bind("PatientId,DoctorId,MedicationName,Dosage,Duration")] Prescription model)
    {
        var patient = _db.Patients.FirstOrDefault(p => p.Id == model.PatientId);
        var doctor = _db.Doctors.FirstOrDefault(d => d.Id == model.DoctorId);

        if (!ModelState.IsValid || patient == null || doctor == null)
        {
            if (ModelState.IsValid) ModelState.AddModelError("", "Выберите пациента и врача.");
            FillLists();
            return View(model);
        }

        var prescription = Prescription.CreatePrescription(patient, doctor, model.MedicationName, model.Dosage, model.Duration);
        _db.Prescriptions.Add(prescription);
        _db.SaveChanges();
        TempData["Message"] = "Назначение создано.";
        return RedirectToAction(nameof(Index));
    }

    private void FillLists()
    {
        ViewBag.Patients = new SelectList(_db.Patients.ToList().OrderBy(p => p.FullName).ToList(), "Id", "FullName");
        ViewBag.Doctors = new SelectList(_db.Doctors.ToList().OrderBy(d => d.FullName).ToList(), "Id", "FullName");
    }
}
